<div class="row">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-8">
        <h1>About Us</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam iste rerum eaque eius ab expedita eum maxime debitis nesciunt voluptatem impedit blanditiis perferendis
            consectetur natus autem, fuga doloribus beatae totam.</p>
        <br>
        <p>Ex minim voluptate non aliquip ut et commodo tempor non minim nulla nostrud excepteur. Qui eiusmod reprehenderit cillum anim magna aliqua ea anim dolore ut. Excepteur Lorem consequat duis consequat excepteur anim fugiat. Veniam proident eu commodo do velit nulla voluptate et consequat mollit cupidatat ea eu.</p>
    </div>
    <div class="col-sm-2">
    </div>
</div>