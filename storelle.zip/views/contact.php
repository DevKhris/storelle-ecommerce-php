<div class="row">
	<div class="col-sm-2">

	</div>
	<div class="col-sm-8">
		<h1>Contact us</h1>
		<form action="" class="form-control-lg">
			<div class="form-group">
				<label for=""> Subject</label>
				<input type="text" name="subject" class="form-control" id="">
			</div>
			<div class="form-group">
				<label for=""> Email</label>
				<input type="text" name="email" class="form-control" id="">
			</div>
			<div class="form-group">
				<label for=""> Message</label>
				<textarea name="message" id="" cols="30" rows="10" class="form-control"></textarea>
			</div>
			<input type="submit" value="Submit" class="btn btn-product btn-block">
		</form>
	</div>
	<div class="col-sm-2">

	</div>
</div>