<div class="row text-center p-5 m-5 bg-black text-light">
    <div class="col-sm-12 p-5">
        <h1 class="h1">404</h1>
        <p class="text-muted">Document Not Found!</p>
    </div>
</div>