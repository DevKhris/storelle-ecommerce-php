<div class="row">
	<div class="featured img-fluid">
		<h1>Shop</h1>
		<p>Your favorite products at the distance of one tap</p>
	</div>
</div>
<?php
require_once 'products.php';
?>