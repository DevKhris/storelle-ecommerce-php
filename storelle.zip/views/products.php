<?php

namespace App\Views;

?>
<h2 class="h2 text-center pb-5">Recently Added Products</h2>
<div class="row justify-content-md-center mt-5 mb-5" id="products" onload="requestProducts()">
</div>
<script>

</script>