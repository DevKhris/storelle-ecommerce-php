<?php 
use App\Application;
?>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Storelle</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
<!-- Custom Styles -->
<link rel="stylesheet" href="/assets/css/styles.min.css">
<!-- Google Foonts -->
<link href="https://fonts.googleapis.com/css2?family=Abel&family=Noto+Sans+SC:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
