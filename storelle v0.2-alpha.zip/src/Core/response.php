<?php

namespace App\Core;

/**
 * Class Response
 * 
 * @author Christian Hernandez (@DevKhris) <devkhris@outlook.com>
 * @package namespace app\core;
 */

class Response 
{
    public $res;
}
?>